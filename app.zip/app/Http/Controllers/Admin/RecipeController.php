<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Recipe;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Illuminate\Support\Str;

class RecipeController extends Controller
{
    public function index()
    {
        return Inertia::render('Admin/Recipes/Index',[
            'recipes'=>Recipe::latest()->get()
        ]);
    }

    public function create()
    {
        return Inertia::render('Admin/Recipes/Create');
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'title'=>'required',
            'image'=>'nullable|image',
            'short_description'=>'nullable',
            'description'=>'nullable',
            'prep_time'=>'nullable|integer',
            'serves'=>'nullable|integer',
            'ingredients'=>'nullable|array',
            'steps'=>'nullable|array',
     ]);
        if($request->hasFile('image')){
            $data['image']=$request->image->store('recipes','public');
        }

        $data['slug']=Str::slug($data['title']);

        Recipe::create($data);

        return redirect()->route('admin.recipes.index');
    }

    public function edit(Recipe $recipe)
    {
        return Inertia::render('Admin/Recipes/Edit',[
            'recipe'=>$recipe
        ]);
    }

public function update(Request $request, Recipe $recipe)
{
    $data = $request->validate([
        'title'             => 'required|string|max:255',
        'short_description' => 'nullable|string',
        'description' => 'nullable|string',
        'prep_time'          => 'nullable|integer',
        'serves'            => 'nullable|integer',
        'ingredients'       => 'nullable|array',
        'ingredients.*'     => 'nullable|string',
        'steps'             => 'nullable|array',
        'steps.*'           => 'nullable|string',
        'image'             => 'nullable|image',
    ]);

    if ($request->hasFile('image')) {
        $data['image'] = $request->file('image')->store('recipes', 'public');
    }

    // regenerate slug if title changed
    if ($data['title'] !== $recipe->title) {
        $data['slug'] = Str::slug($data['title']);
    }

    $recipe->update($data);

    return back()->with('success', 'Recipe updated successfully');
}
    public function destroy(Recipe $recipe)
    {
        $recipe->delete();
        return back();
    }
}