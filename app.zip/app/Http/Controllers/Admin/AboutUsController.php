<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AboutUsSetting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Inertia\Inertia;

class AboutUsController extends Controller
{
    public function show()
    {
        return Inertia::render('Admin/AboutUs/Show', [
            'about' => AboutUsSetting::first(),
        ]);
    }

    public function edit()
    {
        return Inertia::render('Admin/AboutUs/Edit', [
            'about' => AboutUsSetting::first(),
        ]);
    }

    public function update(Request $request)
    {
    $about = AboutUsSetting::firstOrCreate([]);

    /* ================= HERO SLIDER ================= */
    $heroSliders = [];

foreach ($request->hero_sliders ?? [] as $slide) {

    // 🚨 SAFETY: Convert string slide into array
    if (is_string($slide)) {
        $slide = [
            'image' => $slide,
        ];
    }

    if (!is_array($slide)) {
        continue; // skip invalid entries
    }

    // IMAGE HANDLING
    if (isset($slide['image']) && $slide['image'] instanceof \Illuminate\Http\UploadedFile) {
        $slide['image'] = $slide['image']->store('about/hero', 'public');
    } elseif (!empty($slide['image']) && is_string($slide['image'])) {
        // keep old image
        $slide['image'] = $slide['image'];
    } else {
        $slide['image'] = null;
    }

    $heroSliders[] = [
        'image'            => $slide['image'],
        'altTitle'         => $slide['altTitle'] ?? '',
        'altTag'           => $slide['altTag'] ?? '',
        'small_title'      => $slide['small_title'] ?? '',
        'big_title'        => $slide['big_title'] ?? '',
        'subtitle'         => $slide['subtitle'] ?? '',
        'hero_button_text' => $slide['hero_button_text'] ?? '',
        'hero_button_link' => $slide['hero_button_link'] ?? '',
    ];
}


    /* ================= VISION ================= */
    $vision = $request->vision ?? [];

    if ($request->hasFile('vision.image')) {
        $vision['image'] = $request->file('vision.image')->store('about/vision', 'public');
    }

    /* ================= MISSION ================= */
    $mission = $request->mission ?? [];

    if ($request->hasFile('mission.image')) {
        $mission['image'] = $request->file('mission.image')->store('about/mission', 'public');
    }

    /* ================= CORE VALUES ================= */
    $values = [];

    foreach ($request->values ?? [] as $value) {
        $values[] = [
            'title' => $value['title'] ?? '',
            'text'  => $value['text'] ?? '',
        ];
    }
$manufacturing = $request->manufacturing ?? [];

foreach ($manufacturing['items'] ?? [] as $i => $item) {

    // ICON UPLOAD
    if (isset($item['iconFile']) && $item['iconFile'] instanceof \Illuminate\Http\UploadedFile) {
        $manufacturing['items'][$i]['icon'] =
            $item['iconFile']->store('about/manufacturing/icons', 'public');
    }
    elseif (!empty($item['icon']) && is_string($item['icon'])) {
        // keep old icon path
        $manufacturing['items'][$i]['icon'] = $item['icon'];
    }
    else {
        $manufacturing['items'][$i]['icon'] = null;
    }

    // KEEP ORDER
    $manufacturing['items'][$i] = [
        'icon'        => $manufacturing['items'][$i]['icon'],
        'title'       => $item['title'] ?? '',
        'description' => $item['text'] ?? '',
    ];
}
    /* ================= LEADERSHIP ================= */
    $leadership = $request->leadership ?? [];

    foreach ($leadership['members'] ?? [] as $i => $member) {
        if (isset($member['image']) && $member['image'] instanceof \Illuminate\Http\UploadedFile) {
            $leadership['members'][$i]['image'] =
                $member['image']->store('about/leadership', 'public');
        }
    }

    /* ================= CERTIFICATIONS ================= */
    $certifications = $request->certifications ?? [];

    foreach ($certifications['highlights'] ?? [] as $i => $item) {
        if (isset($item['image']) && $item['image'] instanceof \Illuminate\Http\UploadedFile) {
            $certifications['highlights'][$i]['image'] =
                $item['image']->store('about/certifications/highlights', 'public');
        }
    }

    foreach ($certifications['logos'] ?? [] as $i => $logo) {
        if ($logo instanceof \Illuminate\Http\UploadedFile) {
            $certifications['logos'][$i] =
                $logo->store('about/certifications/logos', 'public');
        }
    }

    /* ================= GLOBAL NETWORK ================= */
    $globalNetwork = [
        'label' => $request->input('global_network.label'),
        'title' => $request->input('global_network.title'),
        'map_embed' => $request->input('global_network.map_embed'),
        'location' => $request->input('global_network.location', []),
        'form' => [
            'enabled' => $request->boolean('global_network.form.enabled'),
            'submit_email' => $request->input('global_network.form.submit_email'),
        ],
    ];

    /* ================= REGIONAL PRESENCE ================= */
    $regional = $request->regional_presence ?? [];

    foreach ($regional['countries'] ?? [] as $i => $country) {
        if (isset($country['flag']) && $country['flag'] instanceof \Illuminate\Http\UploadedFile) {
            $regional['countries'][$i]['flag'] =
                $country['flag']->store('about/flags', 'public');
        }
    }

    /* ================= SAVE ================= */
    $about->update([
        'meta_title'       => $request->meta_title,
        'meta_description' => $request->meta_description,
        'meta_keywords'    => $request->meta_keywords,

        'hero_sliders'     => $heroSliders,
        'label'            => $request->label,
        'title'            => $request->title,
        'description'      => $request->description,
        'vision'           => $vision,
        'mission'          => $mission,
        'values'           => $values,
        'leadership'       => $leadership,
        'certifications'   => $certifications,
        'global_network'   => $globalNetwork,
        'regional_presence'=> $regional,
        'manufacturing' => $manufacturing,
    ]);

    return redirect()
        ->route('admin.about.show')
        ->with('success', 'About Us updated successfully');
    }
}