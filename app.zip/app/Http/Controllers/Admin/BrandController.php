<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Brand;
use App\Models\PageSetting;
use Inertia\Inertia;
use Illuminate\Support\Str;

class BrandController extends Controller
{
    public function index()
    {
        return Inertia::render('Admin/Brands/Show', [
            'brands' => Brand::latest()->get(['id','name','slug','logo','created_at'])
        ]);
    }

    public function create()
    {
        return Inertia::render('Admin/Brands/Create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|unique:brands,name'
        ]);

        $slug = Str::slug($request->name);

        $brand = Brand::create([
            'name' => $request->name,
            'slug' => $slug,
            'description' => $request->description,
            'meta_title' => $request->meta_title,
            'meta_description' => $request->meta_description,
        ]);

        PageSetting::firstOrCreate(
            ['brand_id' => $brand->id],
            ['slug' => $slug, 'title' => $brand->name]
        );

        return redirect()->route('admin.brands.index')
            ->with('success','Brand & Page created');
    }

    public function edit(Brand $brand)
    {
        $page = PageSetting::where('brand_id',$brand->id)->first();

        return Inertia::render('Admin/Brands/Edit', [
            'brand' => $brand,
            'page'  => $page?->sections ?? []
        ]);
    }

    public function update(Request $request, Brand $brand)
    {
        $slug = $request->name !== $brand->name
            ? Str::slug($request->name)
            : $brand->slug;

        $brand->update([
            'name' => $request->name,
            'slug' => $slug,
            'meta_title' => $request->meta_title,
            'meta_description' => $request->meta_description,
        ]);

        $page = PageSetting::where('brand_id',$brand->id)->first();

        if ($page) {
            $page->update([
                'slug' => $slug,
                'title'=> $brand->name,
                'sections'=>$request->input('page.sections',[])
            ]);
        }

        return back()->with('success','Brand & Page updated');
    }
}
