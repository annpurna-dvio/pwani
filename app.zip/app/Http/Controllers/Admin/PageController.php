<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\PageSetting;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Illuminate\Support\Str;
use App\Models\Recipe;
use App\Models\Brand;

class PageController extends Controller
{
    public function index()
    {
        return Inertia::render('Admin/PageIndex', [
            'pages' => PageSetting::latest()->get(),
            'recipes' => Recipe::where('is_published', true)->get(['id', 'title']),
            'brands' => Brand::where('is_active', true)->get(['id','name']),
        ]);
    }

    public function create()
    {
        return Inertia::render('Admin/PageCreate', [
            'page' => null,
            'recipes' => Recipe::where('is_published', true)->get(['id', 'title']),
            'brands' => Brand::where('is_active', true)->get(['id','name', 'slug']),
        ]);
    }

    public function edit(PageSetting $page)
    {
        return Inertia::render('Admin/PageCreate', [
            'page' => $page,
            'recipes' => Recipe::where('is_published', true)->get(['id', 'title']),
            'brands' => Brand::where('is_active', true)->get(['id','name', 'slug']),
        ]);
    }

    public function store(Request $request)
    {
    $data = $this->validatedData($request);

    /* HERO IMAGE */
    if (!empty($data['sections']['hero']['image']) &&
        $data['sections']['hero']['image'] instanceof \Illuminate\Http\UploadedFile) {

        $data['sections']['hero']['image'] =
            $data['sections']['hero']['image']->store('pages/hero', 'public');
    }

    /* WHY CHOOSE US ICONS */
    if (!empty($data['sections']['why_choose_us']['items'])) {
        foreach ($data['sections']['why_choose_us']['items'] as $i => $item) {
            if (!empty($item['icon']) && $item['icon'] instanceof \Illuminate\Http\UploadedFile) {
                $data['sections']['why_choose_us']['items'][$i]['icon'] =
                    $item['icon']->store('pages/why-choose-us', 'public');
            }
        }
    }

    /* HEALTH BENEFITS */
    if (!empty($data['sections']['health_benefits']['items'])) {
        foreach ($data['sections']['health_benefits']['items'] as $i => $item) {
            if (!empty($item['image']) && $item['image'] instanceof \Illuminate\Http\UploadedFile) {
                $data['sections']['health_benefits']['items'][$i]['image'] =
                    $item['image']->store('pages/health-benefits', 'public');
            }
        }
    }

    /* MEDIA SLIDER */
    if (!empty($data['sections']['media_slider']['items'])) {
        foreach ($data['sections']['media_slider']['items'] as $i => $item) {

            if (!empty($item['thumbnail']) && $item['thumbnail'] instanceof \Illuminate\Http\UploadedFile) {
                $data['sections']['media_slider']['items'][$i]['thumbnail'] =
                    $item['thumbnail']->store('pages/media', 'public');
            }

            if (!empty($item['image']) && $item['image'] instanceof \Illuminate\Http\UploadedFile) {
                $data['sections']['media_slider']['items'][$i]['image'] =
                    $item['image']->store('pages/media', 'public');
            }
        }
    }

    PageSetting::create($data);

    return redirect()->route('admin.pages.index');
    }
    public function update(Request $request, PageSetting $page)
    {
    $data = $this->validatedData($request);

    /* HERO IMAGE */
    if (!empty($data['sections']['hero']['image']) &&
        $data['sections']['hero']['image'] instanceof \Illuminate\Http\UploadedFile) {

        $data['sections']['hero']['image'] =
            $data['sections']['hero']['image']->store('pages/hero', 'public');
    } else {
        $data['sections']['hero']['image'] =
            $page->sections['hero']['image'] ?? null;
    }

    /* WHY CHOOSE US */
    if (!empty($data['sections']['why_choose_us']['items'])) {
        foreach ($data['sections']['why_choose_us']['items'] as $i => $item) {
            if (!empty($item['icon']) && $item['icon'] instanceof \Illuminate\Http\UploadedFile) {
                $data['sections']['why_choose_us']['items'][$i]['icon'] =
                    $item['icon']->store('pages/why-choose-us', 'public');
            }
        }
    }

    /* HEALTH BENEFITS */
    if (!empty($data['sections']['health_benefits']['items'])) {
        foreach ($data['sections']['health_benefits']['items'] as $i => $item) {
            if (!empty($item['image']) && $item['image'] instanceof \Illuminate\Http\UploadedFile) {
                $data['sections']['health_benefits']['items'][$i]['image'] =
                    $item['image']->store('pages/health-benefits', 'public');
            }
        }
    }

    /* MEDIA SLIDER */
    if (!empty($data['sections']['media_slider']['items'])) {
        foreach ($data['sections']['media_slider']['items'] as $i => $item) {

            if (!empty($item['thumbnail']) && $item['thumbnail'] instanceof \Illuminate\Http\UploadedFile) {
                $data['sections']['media_slider']['items'][$i]['thumbnail'] =
                    $item['thumbnail']->store('pages/media', 'public');
            }

            if (!empty($item['image']) && $item['image'] instanceof \Illuminate\Http\UploadedFile) {
                $data['sections']['media_slider']['items'][$i]['image'] =
                    $item['image']->store('pages/media', 'public');
            }
        }
    }

    $page->update($data);

    return redirect()->route('admin.pages.index');
    }

    protected function validatedData(Request $request)
    {
        return $request->validate([
            'title'            => 'required|string|max:255',
            'brand_id'         => 'nullable|exists:brands,id',
            'slug'             => 'required|string|max:255',
            'show_in_sidebar'  => 'boolean',
            'brand_slug'       => 'nullable|string',
            'meta_title'       => 'nullable|string',
            'meta_description' => 'nullable|string',
            'logo'             => 'nullable|string',
            'hero'             => 'nullable|array',
            'sections'         => 'nullable|array',
            'faqs'             => 'nullable|array',
            'usps'             => 'nullable|array',
        ]);
    }
}
