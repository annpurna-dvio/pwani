<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\HomepageSetting;
use Illuminate\Http\Request;
use Inertia\Inertia;

class HomepageController extends Controller
{
    public function show()
    {
        return Inertia::render('Admin/HomepageShow', [
            'homepage' => HomepageSetting::first(),
        ]);
    }

    public function edit()
    {
        return Inertia::render('Admin/HomepageEdit', [
            'homepage' => HomepageSetting::first(),
        ]);
    }

    public function update(Request $request)
    {
        $home = HomepageSetting::firstOrCreate([]);

        /* ---------------- HERO SLIDER ---------------- */
        $heroSliders = [];
        foreach ($request->hero_sliders ?? [] as $slide) {
            if (isset($slide['image']) && $slide['image'] instanceof \Illuminate\Http\UploadedFile) {
                $slide['image'] = $slide['image']->store('homepage/hero', 'public');
            }

            $heroSliders[] = [
                'image' => $slide['image'] ?? null,
                'altTitle' => $slide['altTitle'] ?? '',
                'altTag' => $slide['altTag'] ?? '',
                'small_title' => $slide['small_title'] ?? '',
                'big_title' => $slide['big_title'] ?? '',
                'subtitle' => $slide['subtitle'] ?? '',
                'hero_button_text' => $slide['hero_button_text'] ?? '',
                'hero_button_link' => $slide['hero_button_link'] ?? '',
            ];
        }

        /* ---------------- BRANDS ---------------- */
        $brands = $request->brands ?? [];
        foreach ($brands as $i => $brand) {
            if (isset($brand['logo']) && $brand['logo'] instanceof \Illuminate\Http\UploadedFile) {
                $brands[$i]['logo'] = $brand['logo']->store('homepage/brands', 'public');
            }
        }

        /* ---------------- SUSTAINABILITY ---------------- */
        $sustainability = $request->sustainability ?? [];

        foreach ($sustainability['items'] ?? [] as $i => $item) {
            if (isset($item['image']) && $item['image'] instanceof \Illuminate\Http\UploadedFile) {
                $sustainability['items'][$i]['image'] =
                    $item['image']->store('homepage/sustainability', 'public');
            }
        }

        /* ---------------- SAVE ---------------- */
        $home->update([
            'hero_sliders' => $heroSliders,

            'about_title_small' => $request->about_title_small,
            'about_title_big' => $request->about_title_big,
            'about_description' => $request->about_description,
            'about_link' => $request->about_link,

            'stats' => $request->stats ?? [],
            'brands' => $brands,
            'sustainability' => $sustainability,
            'faqs' => $request->faqs ?? [],
        ]);

        return redirect()->route('admin.homepage.show')
            ->with('success', 'Homepage updated successfully');
    }
}
