<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class HomepageSetting extends Model
{
    protected $fillable = [
        'hero_sliders',
        'about_title_small','about_title_big','about_description','about_link',
        'stats','brands','sustainability','faqs'
    ];

    protected $casts = [
        'hero_sliders' => 'array',
        'stats' => 'array',
        'brands' => 'array',
        'sustainability' => 'array',
        'faqs' => 'array',
    ];
}
