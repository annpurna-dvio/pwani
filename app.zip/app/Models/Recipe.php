<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Recipe extends Model
{
    protected $fillable = [
        'title',
        'slug',
        'short_description',
        'description',
        'image',
        'prep_time',
        'serves',
        'brand_slug',
        'is_published',
        'ingredients',
        'steps',
    ];
    protected $casts = [
    'ingredients' => 'array',
    'steps' => 'array',
];
}
