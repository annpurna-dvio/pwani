<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AboutUsSetting extends Model
{
    protected $fillable = [
        'meta_title',
        'meta_description',
        'meta_keywords',

        'hero_sliders',
        'label',
        'title',
        'description',
        'vision',
        'mission',
        'values',
        'manufacturing',
        'leadership',
        'certifications',
        'global_network',
    ];

    protected $casts = [
        'hero_sliders' => 'array',
        'vision'       => 'array',
        'mission'      => 'array',
        'values'       => 'array',
        'manufacturing' => 'array',
        'leadership' => 'array',
        'certifications' => 'array',
        'global_network' => 'array',
        'regional_presence' => 'array',
    ];
}
