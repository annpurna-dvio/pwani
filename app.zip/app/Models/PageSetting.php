<?php 
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\Brand;

class PageSetting extends Model
{
    protected $fillable = [
        'title',
        'brand_id',
        'slug',
        'show_in_sidebar',
        'brand_slug',
        'meta_title',
        'meta_description',
        'sections',
    ];

    protected $casts = [
        'sections' => 'array',
    ];
    public function brand()
    {
        return $this->belongsTo(Brand::class, 'slug', 'slug');
    }
}
