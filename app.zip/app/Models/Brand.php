<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\AboutUsSetting;
use App\Models\Product;
use App\Models\PageSetting;

class Brand extends Model
{
    protected $fillable = [
        'name','slug','description',
        'meta_title','meta_description',
        'slider'
    ];
    protected $casts = [
        'slider' => 'array',
    ];
    public function products()
    {
        return $this->hasMany(Product::class);
    }
    public function page()
    {
        return $this->hasOne(PageSetting::class, 'slug', 'slug');
    }
}